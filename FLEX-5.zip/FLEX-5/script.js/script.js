$(document).ready(function(){
  $(".container-right > ul >li").hover(function(){
    $(".hr1").show();
  });
  
});
																	

			

			