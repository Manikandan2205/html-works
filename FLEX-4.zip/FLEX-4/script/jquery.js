$(document).ready(function(){
  $(".container-right > ul >li").hover(function(){
    $(".hr1").show();
  });
  
  $(".container-right > ul >li").hover(function(){
    $(".hr6").show();
  });
  
  
  $(".container-right > ul >li").mouseleave(function(){
    $(".hr1").hide();
  });
  
  $(".container-right > ul >li").mouseleave(function(){
    $(".hr6").hide();
  });
  
  
  $(".movies1").hover(function(){
    $(".moviess1").show();
  });
  
  $(".movies1").mouseleave(function(){
    $(".moviess1").hide();
  });
  
  
  
  $(".movies2").hover(function(){
    $(".moviess2").show();
  });
  
  $(".movies2").mouseleave(function(){
    $(".moviess2").hide();
  });
  
  
  $(".movies3").hover(function(){
    $(".moviess3").show();
  });
  
  $(".movies3").mouseleave(function(){
    $(".moviess3").hide();
  });
  
  
  
  $(".movies4").hover(function(){
    $(".moviess4").show();
  });
  
  $(".movies4").mouseleave(function(){
    $(".moviess4").hide();
  });
  
  
   
  $(".movies5").hover(function(){
    $(".moviess5").show();
  });
  
  $(".movies5").mouseleave(function(){
    $(".moviess5").hide();
  });
  
   $(".movies6").hover(function(){
    $(".moviess6").show();
  });
  
  $(".movies6").mouseleave(function(){
    $(".moviess6").hide();
  });
  
  
  
  $(".heart").mouseleave(function(){
    $(".heart").hide();
  });
  
  
  
  
});

